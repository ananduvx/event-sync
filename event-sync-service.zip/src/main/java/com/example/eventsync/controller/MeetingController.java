
package com.example.eventsync.controller;

import com.example.eventsync.model.UnifiedMeeting;
import com.example.eventsync.service.MeetingService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/meetings")
@CrossOrigin
public class MeetingController {

 private final MeetingService service;

 public MeetingController(MeetingService service){
  this.service = service;
 }

 @GetMapping
 public List<UnifiedMeeting> get(){
  return service.getMeetings();
 }
}
