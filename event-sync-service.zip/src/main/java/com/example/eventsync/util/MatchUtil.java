
package com.example.eventsync.util;

import java.time.*;
import java.time.format.*;

public class MatchUtil {

 public static LocalDateTime parseDateTime(String date, String time){
  try{
   if(date.contains("/")){
    date = date.replace("/", "-");
   }
   return LocalDateTime.parse(date+"T"+time);
  }catch(Exception e){
   return null;
  }
 }
}
