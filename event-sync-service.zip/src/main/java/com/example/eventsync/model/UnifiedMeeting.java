
package com.example.eventsync.model;
import java.util.*;

public class UnifiedMeeting{
 public String id;
 public String title;
 public String client;
 public String time;
 public Field<String> location;
 public Field<String> status;
 public List<String> sources;
}
