
package com.example.eventsync.model;
import java.util.Map;

public class Field<T>{
 public T value;
 public boolean conflict;
 public Map<String,T> sourceValues;
}
