
package com.example.eventsync.service;

import com.example.eventsync.model.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.*;

@Service
public class MeetingService {

 private final ObjectMapper mapper = new ObjectMapper();

 public List<Map> load(String file){
  try{
   InputStream is = getClass().getResourceAsStream("/data/"+file);
   return mapper.readValue(is, List.class);
  }catch(Exception e){
   return List.of();
  }
 }

 public List<UnifiedMeeting> getMeetings(){

  List<Map> crm = load("crm_events.json");
  List<Map> cal = load("calendar_events.json");

  List<UnifiedMeeting> result = new ArrayList<>();

  for(Map c: crm){

   boolean matched=false;

   for(Map e: cal){

    if(match(c,e)){
     result.add(merge(c,e));
     matched=true;
     break;
    }
   }

   if(!matched){
    result.add(fromCRM(c));
   }
  }

  return result;
 }

 private boolean match(Map c, Map e){
  try{
   String crmCompany = (String)c.get("client_company");
   String title = (String)e.get("title");
   return title!=null && crmCompany!=null && title.toLowerCase().contains(crmCompany.split(" ")[0].toLowerCase());
  }catch(Exception ex){
   return false;
  }
 }

 private UnifiedMeeting merge(Map c, Map e){
  UnifiedMeeting m = new UnifiedMeeting();
  m.id = UUID.randomUUID().toString();
  m.title = (String)e.get("title");
  m.client = (String)c.get("client_company");
  m.time = e.get("start_time")+"";

  Field<String> loc = new Field<>();
  String crmLoc = (String)c.get("location");
  String calLoc = (String)e.get("location");

  loc.value = calLoc!=null?calLoc:crmLoc;
  loc.conflict = crmLoc!=null && calLoc!=null && !crmLoc.equals(calLoc);
  loc.sourceValues = Map.of("CRM",crmLoc,"Calendar",calLoc);

  m.location = loc;

  Field<String> status = new Field<>();
  status.value = (String)e.get("status");
  status.conflict = !((String)c.get("status")).equalsIgnoreCase((String)e.get("status"));
  status.sourceValues = Map.of("CRM",(String)c.get("status"),"Calendar",(String)e.get("status"));

  m.status = status;

  m.sources = List.of("CRM","Calendar");

  return m;
 }

 private UnifiedMeeting fromCRM(Map c){
  UnifiedMeeting m = new UnifiedMeeting();
  m.id = UUID.randomUUID().toString();
  m.title = (String)c.get("subject");
  m.client = (String)c.get("client_company");
  m.time = c.get("meeting_date")+" "+c.get("meeting_time");

  Field<String> loc = new Field<>();
  loc.value = (String)c.get("location");
  loc.conflict = false;

  m.location = loc;
  m.sources = List.of("CRM");

  return m;
 }
}
